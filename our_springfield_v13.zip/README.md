Our Springfield v1.3

On first load after installing this version, existing local save data is automatically erased ONE TIME and the opening story begins from level 1. Progress earned after the reset is saved normally.

Original yellow-skinned cartoon residents are visible on the town map with light walking movement, names, and task completion indicators. These are original drawings, not extracted EA game artwork.

Upload all files to the GitHub Pages repository. iPhone may need Safari refresh to update the installed app.
