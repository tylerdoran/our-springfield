Our Springfield v1.4 — cartoon town artwork update

Changes: distinctive original cartoon buildings, detailed shop awnings, roof shingles, windows, doors, porches, school/civic clocks, landscaping, flowers, and park/fountain decorations. Existing characters, story progression, saves, pinch zoom, panning, and unlimited money/donuts remain.

This version does NOT reset your progress again. If you already started the v1.3 opening story, it continues.

Upload the files from this ZIP into your GitHub Pages repository, replacing the older files. Reload the iPhone home-screen app; if an older version remains cached, close and reopen or refresh Safari.
